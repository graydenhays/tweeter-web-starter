export interface TweeterResponse {
	readonly success: boolean;
	readonly message: string | undefined;
}